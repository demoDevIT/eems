class AttendanceResult {
  final bool isSuccess;
  final String message;

  AttendanceResult({required this.isSuccess, required this.message});
}
