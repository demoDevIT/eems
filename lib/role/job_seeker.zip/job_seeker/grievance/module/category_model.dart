class CategoryModel {
  final int dropID;
  final String name;

  CategoryModel({required this.dropID, required this.name});
}
