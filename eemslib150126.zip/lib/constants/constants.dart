abstract class Constants {

  // url devit staging:
     static const baseurl ="https://eems.devitsandbox.com/mobileapi/api/"; //sandbox URL
    //static const baseurl ="https://rajemployment.rajasthan.gov.in/mobileapi/api/"; //live URL
     static const janAadhaarBaseUrl ="https://rajemployment.rajasthan.gov.in/api/api/"; //live URL

    // static const loginUrl = "Authentication/Login";
     static const UploadVideo = "${baseurl}Login/UploadVideo";
     static const GetBasicDetails = "${baseurl}Login/GetBasicDetails";

     static const namespace = "http://tempuri.org/";


     //static const String JanAadhaarMembersList = "${baseurl}Common/JanAadhaarMembersList";

    // static const demourl = "https://rajeevika.devitsandbox.com/Service/AppService";


}