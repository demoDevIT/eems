class StaticVariables {
  static String AADHAR_numA = "";
  static String LocosCode = "";
  static String reverted = "";
  static String resetmpin = "";
  static double AMOUNT = 0.0;
  static bool isvalidate = true;
  static String District = "1";
  static String DistrictId = "1";
  static String block = "";
  static String VillageOrg = "";
  static String shg = "";
  static String FyDate = "";
  static String fromDate = "";
  static String toDate = "";
  static String memberNameCredit = "";



}
